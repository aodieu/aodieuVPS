<?php
/**
 * AodieuVPS Server Probe 1.0 (2026) - single-file, read-only PHP 8.4 dashboard.
 * Deploy only behind authenticated private admin access (Nginx HTTP Basic).
 * No exec(), shell, remote scripts, phpinfo(), credentials, or arbitrary paths.
 */
declare(strict_types=1);
header('Content-Type: text/html; charset=UTF-8');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');
header('Cache-Control: no-store, private');
header('Content-Security-Policy: default-src \'none\'; style-src \'unsafe-inline\'; script-src \'none\'; base-uri \'none\'; form-action \'none\'; frame-ancestors \'none\'');
function val(string $s): string { return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function readFileSafe(string $path, int $max = 131072): string {
    if (!is_readable($path) || !is_file($path)) return '';
    $f = @fopen($path, 'rb'); if (!$f) return '';
    $s = (string) @fread($f, $max); @fclose($f); return $s;
}
function prettyBytes(float $bytes): string {
    if ($bytes <= 0) return '0 B';
    $units = ['B','KiB','MiB','GiB','TiB']; $i = 0;
    while ($bytes >= 1024 && $i < count($units)-1) { $bytes /= 1024; $i++; }
    return number_format($bytes, $i ? 1 : 0) . ' ' . $units[$i];
}
function meminfo(): array {
    $data = [];
    foreach (explode("\n", readFileSafe('/proc/meminfo')) as $line) {
        if (preg_match('/^([a-zA-Z_]+):\s+(\d+)\s+kB/', $line, $m)) $data[$m[1]]=(float)$m[2]*1024;
    }
    return $data;
}
function cpuinfo(): array {
    $src = readFileSafe('/proc/cpuinfo');
    preg_match('/^(?:model name|Hardware)\s*:\s*(.+)$/m', $src, $m);
    $cores = preg_match_all('/^processor\s*:/m', $src);
    return [trim($m[1] ?? 'Unavailable'), (int)$cores];
}
function sysinfo(): array {
    $src = readFileSafe('/etc/os-release');
    preg_match('/^PRETTY_NAME="?([^"\n]+)"?$/m', $src, $m);
    $os = $m[1] ?? PHP_OS_FAMILY;
    return [$os, php_uname('r')];
}
function uptime(): string {
    $n = (int)(float) explode(' ', readFileSafe('/proc/uptime'))[0];
    return sprintf('%dd %dh %dm', intdiv($n,86400), intdiv($n%86400,3600), intdiv($n%3600,60));
}
function card(string $title, string $value, string $help = ''): void {
    echo '<article class="stat"><div class="stat-label">',val($title),'</div><div class="stat-value">',val($value),'</div>';
    if ($help !== '') echo '<div class="stat-help">',val($help),'</div>';
    echo '</article>';
}
$mem = meminfo(); $cpu = cpuinfo(); $os = sysinfo();
$total = $mem['MemTotal'] ?? 0; $available = $mem['MemAvailable'] ?? 0;
$memUsed = max(0, $total-$available);
$swapTotal = $mem['SwapTotal'] ?? 0; $swapUsed = max(0, $swapTotal-($mem['SwapFree'] ?? 0));
$diskTotal = @disk_total_space('/home') ?: 0;
$diskFree = @disk_free_space('/home') ?: 0;
$load = function_exists('sys_getloadavg') ? sys_getloadavg() : [];
$extensions = get_loaded_extensions(); natcasesort($extensions);
$limits = ['memory_limit','upload_max_filesize','post_max_size','max_execution_time','max_input_vars','opcache.enable','opcache.memory_consumption','date.timezone'];
$opcache = function_exists('opcache_get_status') ? @opcache_get_status(false) : false;
?>
<!doctype html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex,nofollow,noarchive"><title>AodieuVPS Server Probe</title>
<style>
:root{color-scheme:light dark;--bg:#f5f7fa;--fg:#162234;--card:#fff;--border:#e2e6ed;--muted:#63728a;--accent:#1674db}
@media(prefers-color-scheme:dark){:root{--bg:#0b1018;--fg:#e7ecf5;--card:#161d29;--border:#30394b;--muted:#a6b1c3;--accent:#7fb3ff}}
*{box-sizing:border-box}body{background:var(--bg);color:var(--fg);font:15px/1.55 system-ui,-apple-system,Segoe UI,sans-serif;margin:0}
main{max-width:1120px;padding:32px 18px 60px;margin:auto}.eyebrow{font-size:13px;letter-spacing:.08em;text-transform:uppercase;font-weight:700;color:var(--accent)}h1{font-size:clamp(25px,4vw,37px);margin:4px 0}p{color:var(--muted);margin:0 0 22px}h2{font-size:18px;margin:30px 0 12px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px}.stat,.panel{background:var(--card);border:1px solid var(--border);border-radius:12px;padding:19px}.stat-label{color:var(--muted);font-size:13px}.stat-value{font-size:22px;font-weight:700;margin-top:4px;overflow-wrap:anywhere}.stat-help{color:var(--muted);font-size:12px}
.tablewrap{overflow:auto}table{width:100%;border-collapse:collapse;font-size:14px}td{padding:11px 9px;border-bottom:1px solid var(--border);vertical-align:top}td:first-child{color:var(--muted);width:220px}tr:last-child td{border:none}code{overflow-wrap:anywhere}.pills{display:flex;gap:8px;flex-wrap:wrap}.pill{border:1px solid var(--border);border-radius:40px;padding:5px 11px;font-size:12px;color:var(--muted)}footer{color:var(--muted);font-size:12px;margin-top:28px}
</style></head><body><main>
<div class="eyebrow">AodieuVPS / System diagnostics</div><h1>Server Probe</h1>
<p>Read-only, one-file PHP diagnostics · No shell execution or exposed credentials · <?=val(gmdate('Y-m-d H:i'))?> UTC</p>
<div class="grid">
<?php card('Operating system', $os[0], 'Kernel ' . $os[1]); ?>
<?php card('CPU', (string)$cpu[1].' cores', $cpu[0]); ?>
<?php card('RAM', prettyBytes($memUsed).' / '.prettyBytes($total), 'Available: '.prettyBytes($available)); ?>
<?php card('Swap', prettyBytes($swapUsed).' / '.prettyBytes($swapTotal)); ?>
<?php card('Disk /home', prettyBytes(max(0,$diskTotal-$diskFree)).' / '.prettyBytes($diskTotal), 'Free: '.prettyBytes($diskFree)); ?>
<?php card('Uptime', uptime(), 'Load: '.implode(' / ',array_map(fn($v)=>number_format((float)$v,2),$load ?: []))); ?>
<?php card('PHP', PHP_VERSION, PHP_SAPI); ?>
<?php card('OPcache', $opcache ? 'Enabled' : 'Disabled / unavailable', 'PHP extension: '.(extension_loaded('Zend OPcache')?'Installed':'Not installed')); ?>
</div>
<h2>PHP runtime settings</h2><div class="panel tablewrap"><table><tbody>
<?php foreach ($limits as $key): ?><tr><td><?=val($key)?></td><td><code><?=val((string)ini_get($key))?></code></td></tr><?php endforeach; ?>
</tbody></table></div>
<h2>PHP extensions (<?=count($extensions)?>)</h2><div class="panel pills">
<?php foreach ($extensions as $ext): ?><span class="pill"><?=val($ext)?></span><?php endforeach; ?>
</div>
<footer>Protected administration use only. This report intentionally omits environment variables, database credentials, phpinfo() and private configuration files.</footer>
</main></body></html>
